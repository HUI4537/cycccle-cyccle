// results.js (nextpage.html에서 실행)
const params = new URLSearchParams(window.location.search);
const ageGroup = params.get('ageGroup');
const gender = params.get('gender');
const location = params.get('location');
const motivation = params.get('motivation');
const travelPartner = params.get('travelPartner');
const travelFrequency = params.get('travelFrequency');
const budget = params.get('budget');

// 선택된 조건에 맞는 결과를 화면에 표시하기
const resultContent = document.getElementById('result-content');
resultContent.innerHTML = `
    <h2>Your Travel Preferences</h2>
    <p>Age Group: ${ageGroup}</p>
    <p>Gender: ${gender}</p>
    <p>Location: ${location}</p>
    <p>Travel Motivation: ${motivation}</p>
    <p>Travel Partner: ${travelPartner}</p>
    <p>Travel Frequency: ${travelFrequency}</p>
    <p>Budget: ${budget}</p>
`;
