document.addEventListener('DOMContentLoaded', function() {
    // URL에서 '?' 뒤의 쿼리 문자열 가져오기
    const rawQuery = window.location.search;

    // #raw-query 요소에 쿼리 문자열 표시
    document.getElementById('raw-query').textContent = rawQuery;
});
