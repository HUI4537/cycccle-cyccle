from flask import Flask, render_template, jsonify, send_from_directory
import os
import json

app = Flask(__name__)


DATA_FILE = os.path.join(app.static_folder, "Main", "data.json")

def load_data():
    with open(DATA_FILE, encoding="utf-8") as file:
        return json.load(file)


@app.route("/")
def index():
    return render_template("Main.html")


@app.route("/api/data")
def api_data():
    try:
        data = load_data()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/picture/<path:filename>')
def picture(filename):
    return send_from_directory("picture", filename)

if __name__ == "__main__":
    app.run(debug=True)
