from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory
from flask_mysqldb import MySQL
import MySQLdb.cursors
import hashlib
import os
import json
import re


app = Flask(__name__)


app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'kgm1004@'
app.config['MYSQL_DB'] = 'pythonlogin'


mysql = MySQL(app)


DATA_FILE = os.path.join(app.static_folder, "Main", "data.json")


def load_data():
    try:
        with open(DATA_FILE, encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        return {"error": str(e)}


@app.route("/")
def index():
    return render_template("Main.html")


@app.route("/api/data")
def api_data():
    data = load_data()
    if "error" in data:
        return jsonify(data), 500
    return jsonify(data)


@app.route('/picture/<path:filename>')
def picture(filename):
    return send_from_directory("picture", filename)

# 로그인 페이지
@app.route('/pythonlogin/', methods=['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        hash = hashlib.sha1((password + app.secret_key).encode()).hexdigest()
        
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username, hash))
        account = cursor.fetchone()

        if account:
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            return redirect(url_for('home'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html', msg=msg)

# 로그아웃
@app.route('/pythonlogin/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

# 회원가입 페이지
@app.route('/pythonlogin/register', methods=['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s', (username,))
        account = cursor.fetchone()

        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        else:
            hash = hashlib.sha1((password + app.secret_key).encode()).hexdigest()
            cursor.execute('INSERT INTO accounts VALUES (NULL, %s, %s, %s)', (username, hash, email))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
    return render_template('register.html', msg=msg)

# 홈 페이지
@app.route('/pythonlogin/home')
def home():
    if 'loggedin' in session:
        return render_template('Main.html', username=session['username'], loggedin=True)
    return redirect(url_for('login'))

# 프로필 페이지
@app.route('/pythonlogin/profile')
def profile():
    if 'loggedin' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE id = %s', (session['id'],))
        account = cursor.fetchone()
        return render_template('profile.html', account=account, loggedin=True)
    return redirect(url_for('login'))


@app.context_processor
def inject_loggedin_status():
    return {'loggedin': 'loggedin' in session}


if __name__ == "__main__":
    app.run(debug=True)
